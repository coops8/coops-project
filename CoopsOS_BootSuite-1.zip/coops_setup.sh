#!/bin/bash
echo 'Setting up CoopsOS bootloader...'
